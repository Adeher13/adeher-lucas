<?php
/**
 * @package Devops_Challenge_Junior
 * @version 1.0
 */
/*
Plugin Name: DevOps Challenge Júnior
Plugin URI: https://apiki.com/
Description: Exibe uma linha aleatória da música "Segure o Tchan" no painel administrativo.
Author: Apiki WordPress
Version: 1.0
Text Domain: devops-challenge
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto ao arquivo
}

/**
 * Retorna uma linha aleatória da música "Segure o Tchan".
 *
 * @return string
 */

function apiki_segura_o_tchan() {
    $lyrics = "Pau que nasce torto nunca se endireita
    Menina que requebra a mãe pega na cabeça
    Pau que nasce torto nunca se endireita
    Menina que requebra a mãe pega na cabeça
    Domingo ela não vai (vai, vai)
    Domingo ela não vai não (vai, vai, vai)
    Olha, domingo ela não vai (vai, vai)
    Domingo ela não vai não (vai, vai, vai)
    O pau que nasce torto nunca se endireita
    Menina que requebra a mãe pega na cabeça
    Pau que nasce torto nunca se endireita
    Menina que requebra a mãe pega na cabeça
    Segure o tchan
    Amarre o tchan
    Segure o tchan tchan tchan tchan
    Depois de nove meses você vê o resultado
    Esse é o Gera Samba arrebentando no pedaço
    Joga ela no meio, mete em cima, mete embaixo";

    $lines = explode("\n", $lyrics);
    
    return wptexturize( $lines[ mt_rand( 0, count( $lines ) - 1 ) ] );
}

/**
 * Exibe a frase aleatória no painel administrativo.
 */
function devops_challenge() {
    $chosen_lyric = apiki_segura_o_tchan();
    $lang_attr    = '';

    if ( 'en_' !== substr( get_user_locale(), 0, 3 ) ) {
        $lang_attr = ' lang="en"';
    }

    printf(
        '<p id="devop"><strong>%s</strong> <span%s>%s</span></p>',
        esc_html__( 'Segure o Tchan:', 'devops-challenge' ),
        esc_attr( $lang_attr ),
        esc_html( $chosen_lyric )
    );
}

add_action( 'admin_notices', 'devops_challenge' );

/**
 * Adiciona estilos CSS para exibição da frase no painel.
 */
function devop_css() {
    echo "
    <style type='text/css'>
        #devop {
            float: right;
            padding: 10px;
            margin: 0;
            font-size: 14px;
            line-height: 1.5;
            background: #f1f1f1;
            border-left: 4px solid #007cba;
            color: #23282d;
            max-width: 350px;
        }
        .rtl #devop {
            float: left;
            border-left: none;
            border-right: 4px solid #007cba;
        }
        .block-editor-page #devop {
            display: none;
        }
        @media screen and (max-width: 782px) {
            #devop {
                float: none;
                padding-left: 0;
                padding-right: 0;
                max-width: 100%;
            }
        }
    </style>
    ";
}

add_action( 'admin_head', 'devop_css' );

?>